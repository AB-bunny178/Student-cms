import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";
import { AttendancePoint } from "@/lib/api";

interface AttendanceChartProps {
  data: AttendancePoint[];
}

const AttendanceChart = ({ data }: AttendanceChartProps) => {
  // Transform data for chart display
  const chartData = data.map((point, index) => {
    const attendedCount = data.slice(0, index + 1).filter(p => p.attended === 1).length;
    const totalCount = index + 1;
    const cumulativePercentage = totalCount > 0 ? (attendedCount / totalCount) * 100 : 0;
    
    return {
      date: point.date,
      attended: point.attended,
      cumulative: Math.round(cumulativePercentage)
    };
  });

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="font-medium text-foreground">{`Date: ${label}`}</p>
          <p className="text-chart-primary">
            {`Daily: ${payload[0].value === 1 ? 'Present' : 'Absent'}`}
          </p>
          {payload[1] && (
            <p className="text-chart-secondary">
              {`Cumulative: ${payload[1].value}%`}
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  if (data.length === 0) {
    return (
      <Card className="col-span-full border-2 hover:shadow-md transition-shadows">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Attendance Trend Analysis
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Track your attendance pattern over time
          </p>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-80 w-full flex items-center justify-center">
            <p className="text-muted-foreground">No attendance data available</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="col-span-full border-2 hover:shadow-md transition-shadows">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          Attendance Trend Analysis
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Track your attendance pattern over time
        </p>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => {
                  try {
                    return new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                  } catch {
                    return value;
                  }
                }}
              />
              <YAxis 
                tick={{ fontSize: 12 }}
                domain={[0, 1]}
                tickFormatter={(value) => value === 1 ? 'Present' : 'Absent'}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="attended"
                fill="hsl(var(--chart-primary))"
                name="Daily Attendance"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center gap-6 mt-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-chart-primary"></div>
            <span>Daily Attendance (Present/Absent)</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AttendanceChart;